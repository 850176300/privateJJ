package info.guardianproject.emoji;

import android.content.res.Resources;

public class Emoji {

	String name;
	String unicode;
	String category;
	String moji;
	String emoticon;
	String assetPath;
	
	Resources res;
}
