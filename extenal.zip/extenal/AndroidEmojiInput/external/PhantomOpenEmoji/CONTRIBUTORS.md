Custom Faces Backers
====================

Custom Animated Backers
=======================
Brian Redbeard

A.Tabisz
Meniou

bags mc ribbit
njx
Einstein, the dog.

Mr. Daniel Scott Fowler


Freeway hosted cloud
A. B. Salisbury

Josh Vera
Call me with yuilop.


Onery
Matt S


Custom Backers
==============
Naya J.
Rod Dorman
Ryan Kaldari
Dave LeCompte
Themonsterfactory.com
ocean dive academy new jersey usa

Bridge
The Grape

Thomas Barber
Donald C. Kirker and webOS-Ports
Key Bump Apparel
Mark Atwood, the FallenPegasus
favrik
Glen Cooper
Marcus Hays
Adam Baxter
Peter Halasz
Ken Ishimoto


Modified Animation Backers
==========================
https://github.com/bgok

Animated Version Backers
========================
Arvid Andersson
Victor Westmann
Daniel "Crusher" Nersveen
Michael Dandy


Alternative Version Backers
===========================
The Matthew, Karen, Guen, and Anya Family
Justin Kazmark
Jy Yaworski
fidelinho
Adam Neuwirth
nickythegreek
Jo-Herman Haugholt


Vander Vander Gamma Iota Zeta


Prioritized Backers
===================
Rompcat
Benjamin Bangsberg
mike mg
Peether
doomcup
Aleksandr Panzin
anonymous
patter-app.net
Eric Nikolaisen

Joonas Pihlajamaa


Lloyd Smart
wispfrog

Noah Greenstein
Oliver Salzburg
Lunasea Studios
Lars Ivar Igesund
Michael B
Hein-Pieter van Braam
rklopfer
Daniel Devine
Fred Benenson
Hans de Wolf
xfer
Laura47

Markj
Rudy Dreamingrudes Valenta

Antón Campos
Cynthia McCoy

Glenn Møller
Krysanto
Dmitry Pashkevich
Sebastian Schauenburg
Josh Freeman
unki2aut
Yuki Kodama
wireclub
Simonas Kazlauskas
barakmich
Świstak
Evereq
Mike Boers
Fotini B.
Bas Kok
Ikaraam Ullah
Jonah Libster
Damien Goujard
Elena Maureen Martinez
Matthew Ender
Merleawe | Foodie For My Tastebuds
Kim Baumann Larsen
Pat May http://www.maycoworld.net
Khalid Abuhakmeh

Brian Kemp
Letia Nichols
Unspecial Ando
Anh Vu
Sébastien Hut
KS.GVN

Mike Canfield
Joel Thoms
Jory Felice
Finallyanime!
Albert L Perrien II

Nick Richards
Jorge Lugo
Seto Konowa
rastilin@gmail.com
ErickaJo
Ken Gander
Michael Day
geekahedron
Robert Adam, II


Backers
=======
Jakub "Wasiu" Wasiluk
0
Colin Dean
Gabriel von Winckler
jackquack
Randall Dederick
Ben Dreidel
Arran Ubels

Michael Pleier
Michael Chang (@cbhl)
Jan-Olaf Bakker
Gregg (greggman) Tavares
Marcello 'piffy' Missiroli
Anonymous
Matthew Amster-Burton
OO-Dragon
Mykhailo Parfeniuk
michael mcgregor
Angela Goebel
Adam Luchjenbroers
Joey Vizcarrondo

SiaynoqMage
Generaal
Julian Tith
Timothy "Vyse Dyne" Geary
Flaki
AsHuRe
Буров Дмитрий

zzken

Oliver
Michael Grosser
Frederico Silva
Arffeh
acasajus
Francesco
Javier Aravena
Jordan Budisantoso
Doug Roos
iGEL
Mattias Dahlberg
Alex Kirkland
Hao Gao
Emil Stenström
Jeremy Douglass
Schatzi
Ready Chi
Charlie Block
Eric Butler
Yoshiki Fujiwara
andrew chudog chua
A.Trance
Randall Kirby
BDQ
H Kevin Glover II
Aicke Schulz
Chris Lee
Bethany Sumner
Minhlicious
Alie Tan (www.alielee.com)
April Carter Grant
SomethingSketchy

Jamiel Almeida
Kyle Bohlander
Alexander Y. Hawson, M.D.
JustinChung.com
BarelyNerdy

Rafiki Sinclair
Allan Puertollano
cmhoudini
Brian Dysart

