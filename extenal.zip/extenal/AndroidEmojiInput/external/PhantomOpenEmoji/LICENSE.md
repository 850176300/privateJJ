When distributed as a font the SIL Open Font License is applied.
All source is licensed under the MIT License.
All graphical assets are licensed under the CreativeCommons 3.0 License [CC-By with attribution requirement waived].
Edit, use, distribute as you please but never claim emoji and source created by Genshin Souzou as your own.
All images created by Genshin Souzou are copyright Genshin Souzou.
Images not created by Genshin Souzou will be listed with their copyright owners noted.
Submitting code or images to Phantom Open Emoji means submiting those images to the above licenses.
If you do not accept distrobution of your copyrighted materials under the above licenses DO NOT submit them for inclusion.

Genshin Souzou and all Phantom Open Emoji related parties and developers can not be heald responsible for copyright infirngin images.
If anyone submits an infringing image they will be heald responsible.

Attribution is not required but it is appreciated.
To attribute please write "Emoji by Genshin Souzou K.K. [Phantom Creation Inc] at http://genshin.org ."
