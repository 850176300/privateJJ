AndroidEmojiInput
=================

Android library for adding emoji, stickers and other rich media input and display

- Inteoperable with the Phantom Open Emoji project, specifically the json library format: 
https://github.com/Genshin/PhantomOpenEmoji

- "/samples" show how to call EmojiManager, display emoji in a grid, and process a textfield

- "stickerpack" show how to build plug-in/add-on APKs with more emoji and stickers
